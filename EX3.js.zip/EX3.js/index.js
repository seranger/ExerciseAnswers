import mysql from "mysql2/promise";

import dotenv from "dotenv";

dotenv.config();
const pool = mysql.createPool({
    hostname: process.env.HOSTNAME,
    user: process.env.USER,
    password: process.env.PASSWORD,
    database: process.env.DATABASE,
})
 
console.log(20);

const getUsers = async () => {
    let [data] = await pool.query("SELECT * FROM users ORDER BY id DESC");
    return data;
}

const getProducts = async () => {
    let [data] = await pool.query("SELECT * FROM products");
    return data;
}

const deleteProducts = async (product_code) => {
    let [data] = await pool.query("DELETE *FROM products WHERE product_code= ?", [product_code]);
}
console.log(await getUsers());
console.log(await getProducts());
deleteProducts('baro1');

const addProduct = async (product_code, product_name, product_price, product_quantity) => {
    let [data] = await pool.query("INSERT INTO products (product_code, product_name, product_price, product_quantity) VALUES (?,?,?,?)", [product_code, product_name, product_price, product_quantity]);
    return data;
}
addProduct('jely1','Jelly Tots', 15.99, 20 );

const updateProduct = async (product_code, product_name, product_price, product_quantity) => {
    let [data] = await pool.query("UPDATE products SET product_name= ?, product_price= ?, product_quantity= ? WHERE product_code= ?", [product_name, product_price, product_quantity, product_code]);
    return data;
}

updateProduct('jely1','Jelly Tots', 15.99, 21 );