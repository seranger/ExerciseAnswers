import mysql from 'mysql2/promise';
import dotenv from 'dotenv';
import express from 'express';

dotenv.config();



const pool = mysql.createPool({
    host: process.env.HOST,
    user: process.env.USER,
    password: process.env.PASSWORD,
    database: process.env.DATABSE,
})

const app = express();
app.use (express.json());

app.get('/products',async(req,res)=>{
    res.json(await getAllProducts());
})

app.get('/products/:product_code',async(req,res)=>{
    res.json(await getProduct(req.params.product_code));
})
app.post('/products',async(req,res)=>{
    let {product_name,product_price,product_quantity} = req.body; 
    console.log(req.body);
    res.json({
    products: await addProduct(product_name,product_price,product_quantity)
    });
})
app.delete('/products/:product_code',async(req,res)=>{
    res.json({
    products: await deletProduct(req.params.product_code)
    });
})
app.patch('/products/:product_code',async(req,res)=>{
    let {product_name,product_price,product_quantity} = req.body; 
    console.log(req.body);

    res.json({
    products: await updateProduct(product_name,product_price,product_quantity,req.params.product_code)
    });
})

app.get('/users',async(req,res)=>{
    res.json(await getAllUsers());
})

app.get('/users/:id',async(req,res)=>{
    res.json(await getUser(req.params.id));
})
app.post('/users',async(req,res)=>{
    let {email,first_name,last_name,password} = req.body; 
    console.log(req.body);
    res.json({
    users: await addUser(email,first_name,last_name,password)
    });
})
app.delete('/users/:id',async(req,res)=>{
    res.json({
    products: await deletUser(req.params.id)
    });
})


app.listen(3000, () => console.log('Server started on port 3000'));
console.log(30);

const getAllProducts = async () => {
    let [data] = await pool.query ('SELECT *FROM products');
    return data;
}

const getProduct = async (product_code) => {
    let [data] = await pool.query ('SELECT *FROM products WHERE product_code = ?', [product_code]);
    return data;
}

const addProduct = async (product_code,product_name,product_price,product_quantity) => {
    let [data] = await pool.query ('INSERT INTO products (product_code,product_name,product_price,product_quantity) VALUES (?,?,?,?)', [product_code,product_name,product_price,product_quantity]);
    return data;
}

const deletProduct = async (product_code) => {
    let [data] = await pool.query ('DELETE FROM products WHERE product_code = ?', [product_code]);
    return data;
}

const updateProduct = async (product_code,product_name,product_price,product_quantity) => {
    pool.query('UPDATE products SET product_name = ?, product_price = ?, product_quantity = ? WHERE product_code = ?', [product_name,product_price,product_quantity,product_code]);
    console.log( await getAllProducts());
}


const getAllUsers = async () => {
    let[data] = await pool.query ('SELECT *FROM users');
    return data;
}

const getUser = async (id) => {
    let [data] = await pool.query ('SELECT *FROM users WHERE id = ?', [id]);
    return data;
}

const addUser = async (id,email,first_name,last_name,password) => {
    let [data] = await pool.query ('INSERT INTO users (id,email,first_name,last_name,password) VALUES (?,?,?,?,?)', [id,email,first_name,last_name,password]);
    return data;
}

const deleteUser = async (id) => {
    let [data] = await pool.query ('DELETE FROM users WHERE id = ?', [id]);
    return data;
}
