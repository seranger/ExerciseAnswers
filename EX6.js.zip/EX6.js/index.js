import dotenv from "dotenv";
import express from "express";
import cors from "cors";
import employeesRouter from "./routes/employees.js";

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());
app.use("/employees", employeesRouter);

app.listen(3000, () => {
    console.log("https://localhost:3000");    
})
console.log(30);