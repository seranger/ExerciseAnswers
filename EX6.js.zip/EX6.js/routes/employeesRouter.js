import express, { Router } from 'express';
import { getEmployeesCon, getSingleEmployeeCon, addEmployeeCon, deleteEmployeesCon, deleteSingleEmployeeCon, getEmployeeSACon } from '../controllers/employeesController.js';

const router = express.Router();


router.get('/', getEmployeesCon);

router.get('/:employee_id', getSingleEmployeeCon);

router.post('/', addEmployeeCon);

router.delete('/:employee_id', deleteSingleEmployeeCon);

router.delete('/', deleteEmployeesCon);

router.get('/:department_id', getEmployeeSACon);

// allows to be used outside of file
export default router;