import { getSingleEmployee,getAllEmployees,addEmployee,deleteSingleEmployee,deleteAllEmployees,getEmployeeSA } from "../models/employeesDB";
const getAllEmployeesCon = async(req,res)=>{
    res.json(await getAllEmployees());
}

const getSingleEmployeeCon = async(req,res)=>{
    res.json(await getSingleEmployee(req.params.employee_id));
}

const addEmployeeCon = async(req,res)=>{
    let {first_name,last_name,email,phone_number,salary,department_id} = req.body; 
    console.log(req.body);
    res.json({
    employees: await addEmployee(first_name,last_name,email,phone_number,salary,department_id)
    });
}

const deleteSingleEmployeeCon = async(req,res)=>{
    res.json({
    employees: await deleteSingleEmployee(req.params.employee_id)
    });
}
const deleteAllEmployeesCon = async(req,res)=>{
    res.json(await deleteAllEmployees());
}

const getEmployeeSACon = async(req,res)=>{
    res.json(await getEmployeeSA());
}

export {getAllEmployeesCon,getSingleEmployeeCon,addEmployeeCon,deleteSingleEmployeeCon,deleteAllEmployeesCon,getEmployeeSACon};
