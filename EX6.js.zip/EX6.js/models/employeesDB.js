import { pool } from "../config/config";

const getAllEmployees = async() => {
    let [data] = await pool.query ('SELECT *FROM employees');
    return data;
}

const getSingleEmployee = async (employee_id) => {
    let[data] = await pool.query ('SELECT *FROM employees WHERE employee_id=?', [employee_id]);
    return data;
}

const addEmployee = async (first_name,last_name,email,phone_number,salary,department_id) => {
    let [data] = await pool.query ('INSERT INTO employees (?,?,?,?,?,?)', [first_name,last_name,email,phone_number,salary,department_id]);
    return data;
}

const deleteSingleEmployee = async (employee_id) => {
    await pool.query ('DELETE FROM employees WHERE employee_id=?', [employee_id]);
    console.log(await getAllEmployees());
}
const deleteAllEmployees = async () => {
    await pool.query ('DELETE FROM employees');
    console.log(await getAllEmployees());
}
const getEmployeeSA = async () => {
    let [data] = await pool.query ('SELECT *FROM employees WHERE department_id=1');
    return data;
}

export {getAllEmployees, getSingleEmployee, addEmployee, deleteSingleEmployee,deleteAllEmployees, getEmployeeSA};