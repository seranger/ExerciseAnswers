import { pool } from "../config/config.js";
const getAllProducts = async () => {
    let [data] = await pool.query ('SELECT *FROM products');
    return data;
}

const getProduct = async (product_code) => {
    let [data] = await pool.query ('SELECT *FROM products WHERE product_code = ?', [product_code]);
    return data;
}

const addProduct = async (product_code,product_name,product_price,product_quantity) => {
    let [data] = await pool.query ('INSERT INTO products (product_code,product_name,product_price,product_quantity) VALUES (?,?,?,?)', [product_code,product_name,product_price,product_quantity]);
    return data;
}

const deletProduct = async (product_code) => {
    let [data] = await pool.query ('DELETE FROM products WHERE product_code = ?', [product_code]);
    return data;
}

const updateProduct = async (product_code,product_name,product_price,product_quantity) => {
    pool.query('UPDATE products SET product_name = ?, product_price = ?, product_quantity = ? WHERE product_code = ?', [product_name,product_price,product_quantity,product_code]);
    console.log( await getAllProducts());
}

export {getAllProducts, getProduct, addProduct, deletProduct, updateProduct};