import express from 'express';
import {getProductsCon, getProductCon, addProductCon, deleteProductCon, updateProductCon} from '../Controller/productsController.js';



// manages paths from different file as I can't use app.get/app.post...
// can't use const app = express(); because we already initialized it in index.js
const router = express.Router();


router.get('/', getProductsCon);

router.get('/:product_code', getProductCon);

router.post('/', addProductCon);

router.delete('/:product_code', deleteProductCon);

router.patch('/:product_code', updateProductCon);

// allows to be used outside of file
export default router;