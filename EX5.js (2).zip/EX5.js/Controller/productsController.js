import {getAllProducts, getProduct, addProduct, deletProduct, updateProduct} from '../model/productsDb.js';
const getProductsCon = async(req,res)=>{
    res.json(await getAllProducts());
}

const getProductCon = async(req,res)=>{
    res.json(await getProduct(req.params.product_code));
}

const addProductCon = async(req,res)=>{
    let {product_name,product_price,product_quantity} = req.body; 
    console.log(req.body);
    res.json({
    products: await addProduct(product_name,product_price,product_quantity)
    });
}

const deleteProductCon = async(req,res)=>{
    res.json({
    products: await deletProduct(req.params.product_code)
    });
}

const updateProductCon = async(req,res)=>{
    let {product_name,product_price,product_quantity} = req.body; 
    console.log(req.body);

    res.json({
    products: await updateProduct(product_name,product_price,product_quantity,req.params.product_code)
    });
}

export {getProductsCon}; export {getProductCon}; export {addProductCon}; export {deleteProductCon}; export {updateProductCon};