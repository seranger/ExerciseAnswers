
import dotenv from 'dotenv';
import express from 'express';
import cors from 'cors';

//importing the routes that we exported
import productsRouter from './routes/productsRouter.js';

dotenv.config();





const app = express();
app.use(cors());
app.use (express.json());

// path , imported file
app.use('/products', productsRouter);

app.listen(3030, () => console.log('http://localhost:3030'));
console.log(30);


app.get('/users',async(req,res)=>{
    res.json(await getAllUsers());
})

app.get('/users/:id',async(req,res)=>{
    res.json(await getUser(req.params.id));
})
app.post('/users',async(req,res)=>{
    let {email,first_name,last_name,password} = req.body; 
    console.log(req.body);
    res.json({
    users: await addUser(email,first_name,last_name,password)
    });
})
app.delete('/users/:id',async(req,res)=>{
    res.json({
    products: await deletUser(req.params.id)
    });
})





const getAllUsers = async () => {
    let[data] = await pool.query ('SELECT *FROM users');
    return data;
}

const getUser = async (id) => {
    let [data] = await pool.query ('SELECT *FROM users WHERE id = ?', [id]);
    return data;
}

const addUser = async (id,email,first_name,last_name,password) => {
    let [data] = await pool.query ('INSERT INTO users (id,email,first_name,last_name,password) VALUES (?,?,?,?,?)', [id,email,first_name,last_name,password]);
    return data;
}

const deleteUser = async (id) => {
    let [data] = await pool.query ('DELETE FROM users WHERE id = ?', [id]);
    return data;
}
