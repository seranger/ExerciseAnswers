import mysql from 'mysql2/promise';
import dotenv from 'dotenv';
import express from 'express';

dotenv.config();

const pool = mysql.createPool({
    host: process.env.HOST,
    user: process.env.USER,
    password: process.env.PASSWORD,
    database: process.env.DATABASE,
})

console.log(12);

const getAllEmployees = async () => {
    let [data] = await pool.query('SELECT * FROM employees');
    return data;
}

console.log(await getAllEmployees());

const getEmployee = async(employee_id)=> {
    let [data] = await pool.query('SELECT *FROM employees WHERE employee_id = ?' , [employee_id]);
    return data
}

console.log (await getEmployee(2));

const addEmployee = async (employee_id, first_name, last_name, email, phone_number, department, salary) => {
    let [data] = await pool.query('INSERT INTO employees (employee_id, first_name, last_name, email, phone_number, department, salary) VALUES (?,?,?,?,?,?,?)', [employee_id, first_name, last_name, email, phone_number, department, salary]);
    return data;
}

console.log (await addEmployee(5, 'Mickey', 'Mouse', 'mickeymouse@example.com', '123-456-7890', 'IT', 50000));

const deleteEmployee = async (employee_id)=> {
    let [data] = await pool.query('DELETE FROM employees WHERE employee_id = ?', [employee_id]);
    return data
}

console.log (await deleteEmployee(5));
console.log (await deleteEmployee(6));
console.log (await deleteEmployee(7));

const updateEmployee = async (first_name, last_name, email, phone_number, department, salary, employee_id) => {
    await pool.query('UPDATE picknsteal.employees SET first_name = ?, last_name = ?, email = ?, phone_number = ?, department = ?, salary = ? WHERE employee_id = ?', [first_name, last_name, email, phone_number, department, salary, employee_id]);
    return await getAllEmployees()
}

console.log (await updateEmployee('Amy', 'Daniels', 'amydaniels@example.com', '123-456-7890', 'IT', 50000, 4));