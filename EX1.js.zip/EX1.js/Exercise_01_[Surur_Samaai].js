import express from 'express';

const app = express();

const PORT = process.env.PORT || 3000;

app.get('/products', (req,res) => {
    res.json({
        message:'This is the GET product path'
    })
})
app.get('/users', (req,res) => {
    res.json({
        message:'This is the GET users path'
    })
})
app.post('/', (req,res) => {
    res.json({
        message:'This is the POST path and something was added'
    })
})
app.patch('/', (req,res) => {
    res.json({
        message:'This is the PATCH path and something was edited'
    })
})
app.delete('/', (req,res) => {
    res.json({
        message:'This is the DELETE path and something was deleted'
    })
})

app.listen(PORT || 3000, () => {
    console.log('http://localhost:' +PORT);
});